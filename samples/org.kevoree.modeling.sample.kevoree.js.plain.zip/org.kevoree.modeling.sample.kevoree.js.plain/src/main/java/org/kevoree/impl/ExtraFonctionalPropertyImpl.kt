package org.kevoree.impl

import org.kevoree.*

class ExtraFonctionalPropertyImpl() : ExtraFonctionalPropertyInternal {
override internal var internal_eContainer : org.kevoree.container.KMFContainer? = null
override internal var internal_containmentRefName : String? = null
override internal var internal_unsetCmd : (()->Unit)? = null
override internal var internal_readOnlyElem : Boolean = false
override internal var internal_recursive_readOnlyElem : Boolean = false
override internal var _portTypes_java_cache :List<org.kevoree.PortTypeRef>? = null
override internal val _portTypes : java.util.HashMap<Any,org.kevoree.PortTypeRef> = java.util.HashMap<Any,org.kevoree.PortTypeRef>()
}
