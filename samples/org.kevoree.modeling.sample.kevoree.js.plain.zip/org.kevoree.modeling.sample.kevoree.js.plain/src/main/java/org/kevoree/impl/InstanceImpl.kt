package org.kevoree.impl

import org.kevoree.*

class InstanceImpl() : InstanceInternal {
override internal var internal_eContainer : org.kevoree.container.KMFContainer? = null
override internal var internal_containmentRefName : String? = null
override internal var internal_unsetCmd : (()->Unit)? = null
override internal var internal_readOnlyElem : Boolean = false
override internal var internal_recursive_readOnlyElem : Boolean = false
override internal var _name : String = ""
override internal var _metaData : String = ""
override internal var _typeDefinition : org.kevoree.TypeDefinition? = null
override internal var _dictionary : org.kevoree.Dictionary? = null
}
