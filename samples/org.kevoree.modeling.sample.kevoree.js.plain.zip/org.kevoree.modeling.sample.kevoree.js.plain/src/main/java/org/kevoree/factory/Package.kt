package org.kevoree.factory
enum class Package {
ORG_KEVOREE
}
