package org.kevoree.factory
object Package {
 public val ORG_KEVOREE : Int = 0
}
