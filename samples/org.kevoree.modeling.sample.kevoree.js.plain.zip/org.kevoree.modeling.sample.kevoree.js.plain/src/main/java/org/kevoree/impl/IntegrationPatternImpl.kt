package org.kevoree.impl

import org.kevoree.*

class IntegrationPatternImpl() : IntegrationPatternInternal {
override internal var internal_eContainer : org.kevoree.container.KMFContainer? = null
override internal var internal_containmentRefName : String? = null
override internal var internal_unsetCmd : (()->Unit)? = null
override internal var internal_readOnlyElem : Boolean = false
override internal var internal_recursive_readOnlyElem : Boolean = false
override internal var _name : String = ""
override internal var _extraFonctionalProperties_java_cache :List<org.kevoree.ExtraFonctionalProperty>? = null
override internal val _extraFonctionalProperties :MutableList<org.kevoree.ExtraFonctionalProperty> = java.util.ArrayList<org.kevoree.ExtraFonctionalProperty>()
override internal var _portTypes_java_cache :List<org.kevoree.PortTypeRef>? = null
override internal val _portTypes : java.util.HashMap<Any,org.kevoree.PortTypeRef> = java.util.HashMap<Any,org.kevoree.PortTypeRef>()
}
